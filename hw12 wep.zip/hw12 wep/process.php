<?php
header('Content-Type: application/json');

$host = "localhost";
$username = "root";
$password = "";
$database = "addressbook";

$conn = new mysqli($host, $username, $password);

$conn->query("CREATE DATABASE IF NOT EXISTS $database");
$conn->select_db($database);

$conn->query("CREATE TABLE IF NOT EXISTS contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(100) NOT NULL,
    lastname VARCHAR(100) NOT NULL,
    street VARCHAR(200) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(50) NOT NULL,
    zip VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $street = $_POST['street'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zip = $_POST['zip'];
    
    $stmt = $conn->prepare("INSERT INTO contacts (firstname, lastname, street, city, state, zip) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $firstname, $lastname, $street, $city, $state, $zip);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Contact added successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => $conn->error]);
    }
    
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $action = isset($_GET['action']) ? $_GET['action'] : '';
    
    if ($action == 'load') {
        $result = $conn->query("SELECT * FROM contacts ORDER BY id DESC");
        $contacts = [];
        
        while ($row = $result->fetch_assoc()) {
            $contacts[] = $row;
        }
        
        echo json_encode($contacts);
    }
    
    if ($action == 'search') {
        $lastname = isset($_GET['lastname']) ? $_GET['lastname'] : '';
        
        $stmt = $conn->prepare("SELECT * FROM contacts WHERE lastname LIKE ? ORDER BY lastname");
        $searchTerm = "%$lastname%";
        $stmt->bind_param("s", $searchTerm);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $contacts = [];
        while ($row = $result->fetch_assoc()) {
            $contacts[] = $row;
        }
        
        echo json_encode($contacts);
        $stmt->close();
    }
}

$conn->close();
?>