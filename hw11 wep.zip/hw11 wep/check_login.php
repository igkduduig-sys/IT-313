<?php
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "login_db";

$conn = new mysqli($host, $username, $password);

$conn->query("CREATE DATABASE IF NOT EXISTS $database");
$conn->select_db($database);

$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
)");

$result = $conn->query("SELECT COUNT(*) as count FROM users");
$row = $result->fetch_assoc();
if ($row['count'] == 0) {
    $conn->query("INSERT INTO users (email, password) VALUES ('admin@example.com', 'admin123')");
    $conn->query("INSERT INTO users (email, password) VALUES ('user@example.com', 'user123')");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $pass = $_POST['password'];
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
    $stmt->bind_param("ss", $email, $pass);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['email'] = $email;
        header("Location: welcome.php");
        exit();
    } else {
        echo "<script>
                alert('Wrong username or password');
                window.location.href='login.html';
              </script>";
    }
}

$conn->close();
?>