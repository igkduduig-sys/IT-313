﻿Public Class Form1
    Private Sub btnSort_Click(sender As Object, e As EventArgs) Handles btnSort.Click
        Dim numbers() As Integer = {Val(txtNum1.Text), Val(txtNum2.Text), Val(txtNum3.Text)}

        ' Sort the array in ascending order
        Array.Sort(numbers)

        ' Display sorted numbers
        lblOutput.Text = "Sorted Numbers: " & String.Join(", ", numbers)
    End Sub
End Class

