﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtNum1 = New System.Windows.Forms.TextBox()
        Me.txtNum3 = New System.Windows.Forms.TextBox()
        Me.txtNum2 = New System.Windows.Forms.TextBox()
        Me.btnSort = New System.Windows.Forms.Button()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtNum1
        '
        Me.txtNum1.Location = New System.Drawing.Point(59, 82)
        Me.txtNum1.Multiline = True
        Me.txtNum1.Name = "txtNum1"
        Me.txtNum1.Size = New System.Drawing.Size(149, 39)
        Me.txtNum1.TabIndex = 0
        '
        'txtNum3
        '
        Me.txtNum3.Location = New System.Drawing.Point(59, 259)
        Me.txtNum3.Multiline = True
        Me.txtNum3.Name = "txtNum3"
        Me.txtNum3.Size = New System.Drawing.Size(149, 39)
        Me.txtNum3.TabIndex = 1
        '
        'txtNum2
        '
        Me.txtNum2.Location = New System.Drawing.Point(59, 169)
        Me.txtNum2.Multiline = True
        Me.txtNum2.Name = "txtNum2"
        Me.txtNum2.Size = New System.Drawing.Size(149, 39)
        Me.txtNum2.TabIndex = 2
        '
        'btnSort
        '
        Me.btnSort.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSort.Location = New System.Drawing.Point(341, 371)
        Me.btnSort.Name = "btnSort"
        Me.btnSort.Size = New System.Drawing.Size(245, 94)
        Me.btnSort.TabIndex = 3
        Me.btnSort.Text = "Sort Numbers"
        Me.btnSort.UseVisualStyleBackColor = True
        '
        'lblOutput
        '
        Me.lblOutput.AutoSize = True
        Me.lblOutput.Font = New System.Drawing.Font("Tahoma", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutput.Location = New System.Drawing.Point(398, 289)
        Me.lblOutput.Margin = New System.Windows.Forms.Padding(55)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Padding = New System.Windows.Forms.Padding(30, 20, 30, 20)
        Me.lblOutput.Size = New System.Drawing.Size(138, 68)
        Me.lblOutput.TabIndex = 4
        Me.lblOutput.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1004, 530)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.btnSort)
        Me.Controls.Add(Me.txtNum2)
        Me.Controls.Add(Me.txtNum3)
        Me.Controls.Add(Me.txtNum1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtNum1 As TextBox
    Friend WithEvents txtNum3 As TextBox
    Friend WithEvents txtNum2 As TextBox
    Friend WithEvents btnSort As Button
    Friend WithEvents lblOutput As Label
End Class
