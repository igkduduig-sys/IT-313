<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['num1']) && isset($_GET['num2'])) {
    $num1 = $_GET['num1'];
    $num2 = $_GET['num2'];
    $method = "GET";
} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['num1']) && isset($_POST['num2'])) {
    $num1 = $_POST['num1'];
    $num2 = $_POST['num2'];
    $method = "POST";
} else {
    die("Error: Invalid data");
}

$sum = $num1 + $num2;
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Result</title>
</head>
<body>
    <h2>Calculation Result</h2>
    <p>First Number: <?php echo $num1; ?></p>
    <p>Second Number: <?php echo $num2; ?></p>
    <p>Sum: <?php echo $sum; ?></p>
    <p>Method Used: <?php echo $method; ?></p>
    
    <br>
    <a href="index.html">Back</a>
</body>
</html>