<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "contact_list";

$conn = new mysqli($host, $username, $password);

$conn->query("CREATE DATABASE IF NOT EXISTS $database");
$conn->select_db($database);

$conn->query("CREATE TABLE IF NOT EXISTS contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL
)");

if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    
    $conn->query("INSERT INTO contacts (name, phone, email) VALUES ('$name', '$phone', '$email')");
    header("Location: contacts.php");
    exit();
}

if (isset($_POST['clear'])) {
    $conn->query("DELETE FROM contacts");
    header("Location: contacts.php");
    exit();
}

$result = $conn->query("SELECT * FROM contacts");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Contact List</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #4CAF50; color: white; }
        input { padding: 8px; margin: 5px; width: 200px; }
        button { padding: 10px 20px; margin: 5px; cursor: pointer; }
        .add-btn { background-color: #4CAF50; color: white; border: none; }
        .clear-btn { background-color: #f44336; color: white; border: none; }
    </style>
</head>
<body>
    <h1>Contact List</h1>
    
    <h2>Add New Contact</h2>
    <form method="POST">
        <input type="text" name="name" placeholder="Name" required>
        <input type="text" name="phone" placeholder="Phone" required>
        <input type="email" name="email" placeholder="Email" required>
        <button type="submit" name="add" class="add-btn">Add Contact</button>
    </form>
    
    <hr>
    
    <h2>Saved Contacts</h2>
    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['phone']; ?></td>
                <td><?php echo $row['email']; ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        
        <form method="POST" onsubmit="return confirm('Are you sure you want to delete all contacts?');">
            <button type="submit" name="clear" class="clear-btn">Clear All Contacts</button>
        </form>
    <?php else: ?>
        <p>No contacts saved.</p>
    <?php endif; ?>
</body>
</html>

<?php
$conn->close();
?>